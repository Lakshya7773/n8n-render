# n8n Render Cloud Worker

Cloud render worker for the YouTube automation system. n8n remains the orchestrator; GitHub Actions performs the render on an ephemeral hosted runner.

## Contract

1. n8n creates `jobs/<job_id>.json` in this repository.
2. n8n dispatches `.github/workflows/render.yml` with only `job_id`.
3. The workflow renders `output/*.mp4` with Remotion.
4. The workflow uploads the result as a short-retention GitHub Actions artifact.
5. n8n polls the run and downloads the artifact.

The small dispatch payload avoids GitHub's 65,535-character `workflow_dispatch` input limit.

## Scope of this first worker

The current composition is deliberately a transport/encoding proof: it accepts the existing n8n render contract and creates valid 16:9 or 9:16 H.264 MP4 output. The next renderer iteration can add the production scene system (images, animated text, captions, music, and narration) without changing the n8n job contract.

## Cost model

Use a **public GitHub repository** with standard GitHub-hosted runners. GitHub currently documents standard runners in public repositories as free and unlimited. Private repositories use plan quotas and can incur charges beyond included usage.
