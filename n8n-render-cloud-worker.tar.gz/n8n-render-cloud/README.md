# n8n Render Cloud Worker
Static Remotion composition + Node render runner for GitHub Actions.
