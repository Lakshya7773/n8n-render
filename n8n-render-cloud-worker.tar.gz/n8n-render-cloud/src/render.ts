import {renderMedia, selectComposition} from '@remotion/renderer';
import {bundle} from '@remotion/bundler';
import fs from 'node:fs/promises';
import path from 'node:path';

const jobPath=process.env.RENDER_JOB||'render-job.json';
async function main(){
  const job=JSON.parse(await fs.readFile(jobPath,'utf8'));
  const outDir=path.resolve('output');
  await fs.mkdir(outDir,{recursive:true});
  const output=path.join(outDir,job.output_name||`render-${Date.now()}.mp4`);
  const serveUrl=await bundle({entryPoint:path.resolve('src/composition.tsx'),webpackOverride:(c:any)=>c});
  const comp=await selectComposition({serveUrl,id:'YTVideo',inputProps:{job}});
  await renderMedia({codec:'h264',serveUrl,composition:comp,inputProps:{job},outputLocation:output,overwrite:true});
  const duration=comp.durationInFrames/(comp.fps||30);
  await fs.writeFile(path.join(outDir,'result.json'),JSON.stringify({status:'rendered',video_file:output,aspect_ratio:job.aspect_ratio||'16:9',duration},null,2));
  console.log(JSON.stringify({status:'rendered',video_file:output,duration}));
}
main().catch(err=>{console.error(err);process.exit(1);});
