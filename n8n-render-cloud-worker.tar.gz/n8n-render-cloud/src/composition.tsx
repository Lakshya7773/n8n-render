import React from 'react';
import {Composition, registerRoot, useCurrentFrame, interpolate} from 'remotion';

export type Scene = {text?: string; title?: string; body?: string; duration?: number; image?: string};
export type RenderJob = {
  type?: 'long_form' | 'short';
  aspect_ratio?: '16:9' | '9:16';
  duration?: number;
  title?: string;
  script?: string;
  scenes?: Scene[];
  visuals?: Scene[];
  captions?: string[];
  output_name?: string;
};

const fps = 30;
const clamp=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));

function Video({job}:{job:RenderJob}) {
  const frame=useCurrentFrame();
  const scenes=job.scenes?.length?job.scenes:job.visuals?.length?job.visuals:[{text:job.script||job.title||''}];
  const width=job.aspect_ratio==='9:16'?1080:1920;
  const height=job.aspect_ratio==='9:16'?1920:1080;
  const opacity=interpolate(frame,[0,15],[0,1],{extrapolateRight:'clamp'});
  const scene=scenes[Math.min(Math.floor(frame/(fps*5)),scenes.length-1)] || {};
  return <div style={{width,height,background:'#080808',color:'white',fontFamily:'Arial,sans-serif',display:'flex',alignItems:'center',justifyContent:'center',padding:80,boxSizing:'border-box'}}>
    <div style={{width:'88%',textAlign:'center',opacity}}>
      <div style={{fontSize:job.aspect_ratio==='9:16'?64:58,fontWeight:800,lineHeight:1.08}}>{job.title||'Untitled'}</div>
      <div style={{marginTop:40,fontSize:job.aspect_ratio==='9:16'?48:38,lineHeight:1.25,opacity:.92}}>{scene.title||scene.text||scene.body||job.script||''}</div>
    </div>
  </div>;
}

export function Root({job}:{job:RenderJob}) {
  const duration=clamp(Number(job?.duration || (job?.type==='short'?45:300)),job?.type==='short'?20:30,900);
  return <Composition id="YTVideo" component={Video} durationInFrames={Math.round(duration*fps)} fps={fps} width={job?.aspect_ratio==='9:16'?1080:1920} height={job?.aspect_ratio==='9:16'?1920:1080} defaultProps={{job}}/>;
}

registerRoot(Root);
