import React from 'react';
import {renderMedia, selectComposition} from '@remotion/renderer';
import {Composition} from 'remotion';
import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import path from 'node:path';

const require = createRequire(import.meta.url);

export type Scene = {
  text?: string;
  title?: string;
  body?: string;
  duration?: number;
  image?: string;
};

export type RenderJob = {
  type?: 'long_form' | 'short';
  aspect_ratio?: '16:9' | '9:16';
  duration?: number;
  title?: string;
  script?: string;
  scenes?: Scene[];
  visuals?: Scene[];
  captions?: string[];
  output_name?: string;
};

const fps = 30;
const clamp = (n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));

function Video({job}:{job:RenderJob}) {
  const scenes = (job.scenes?.length ? job.scenes : job.visuals?.length ? job.visuals : [{text: job.script || job.title || ''}]);
  const width = job.aspect_ratio === '9:16' ? 1080 : 1920;
  const height = job.aspect_ratio === '9:16' ? 1920 : 1080;
  return <div style={{width:'100%',height:'100%',background:'#080808',color:'white',fontFamily:'Arial, sans-serif',display:'flex',alignItems:'center',justifyContent:'center',padding:80,boxSizing:'border-box'}}>
    <div style={{width:'88%',textAlign:'center'}}>
      <div style={{fontSize: job.aspect_ratio==='9:16'?64:58,fontWeight:800,lineHeight:1.08}}>{job.title || 'Untitled'}</div>
      <div style={{marginTop:40,fontSize:job.aspect_ratio==='9:16'?48:38,lineHeight:1.25,opacity:.92}}>{scenes[0]?.title || scenes[0]?.text || job.script || ''}</div>
    </div>
  </div>;
}

function Root({job}:{job:RenderJob}) {
  const width = job.aspect_ratio === '9:16' ? 1080 : 1920;
  const height = job.aspect_ratio === '9:16' ? 1920 : 1080;
  const duration = clamp(Number(job.duration || (job.type==='short'?45:300)), job.type==='short'?20:30, 900);
  return <Composition id="YTVideo" component={Video} durationInFrames={Math.round(duration*fps)} fps={fps} width={width} height={height} defaultProps={{job}} />;
}

const jobPath = process.env.RENDER_JOB || 'render-job.json';
const job: RenderJob = JSON.parse(await fs.readFile(jobPath,'utf8'));
const outDir = path.resolve('output');
await fs.mkdir(outDir,{recursive:true});
const output = path.join(outDir, job.output_name || `render-${Date.now()}.mp4`);
const bundle = await require('@remotion/bundler').bundle({entryPoint:path.resolve('src/render.tsx'),webpackOverride:(c:any)=>c});
const comp = await selectComposition({serveUrl:bundle,id:'YTVideo',inputProps:{job}});
await renderMedia({codec:'h264',serveUrl:bundle,composition:comp,inputProps:{job},outputLocation:output,overwrite:true});
await fs.writeFile(path.join(outDir,'result.json'),JSON.stringify({status:'rendered',video_file:output,aspect_ratio:job.aspect_ratio||'16:9',duration:comp.durationInFrames/fps},null,2));
console.log(JSON.stringify({status:'rendered',video_file:output,duration:comp.durationInFrames/fps}));
